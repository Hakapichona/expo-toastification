# 🍞 expo-toastification

A simple, elegant and lightweight toast notification library for **Expo** and **React Native**.

Inspired by the developer experience of `vue-toastification`, built with **modern React Native and TypeScript best practices**.

# 🔧 Requirements

- Expo SDK >= 49
- React >= 18
- React Native >= 0.71
- uuid >= 8.3.2
- react-native-get-random-values
- react-native-safe-area-context
- react-native-svg

# 📦 Installation
- pnpm add expo-toastification

- npm install expo-toastification

- yarn add expo-toastification

# 🚀 Basic Setup

### 1- Expo Router
```tsx
import { ToastProvider, configureToasts } from "expo-toastification";
import { Slot } from "expo-router";

configureToasts({
  duration: 3500,
  position: "top",
  enterDuration: 350,
  exitDuration: 250,
});

export default function RootLayout() {
  return (
    <ToastProvider>
      <Slot />
    </ToastProvider>
  );
}
```

### 2- Classic Expo / React Native
```tsx
import { ToastProvider } from "expo-toastification";

export default function App() {
  return (
    <ToastProvider>
      {/* your app */}
    </ToastProvider>
  );
}
```

# 🍞 Basic usage

```tsx
import { toast } from "expo-toastification";

toast("Hello world!");

toast.success("Saved successfully");
toast.error("Something went wrong");
toast.info("New update available");
toast.warning("Be careful!");
```

# 🧩 Title + description

Every toast takes a required **title** and an optional **description**.

```tsx
toast.success("Guardado con éxito", {
  description: "Los cambios se guardaron correctamente.",
});

toast.error("Ops!", {
  description:
    "No hay suficientes fondos en la tarjeta para completar la transacción.",
});
```

# 🎨 Custom styles per toast

`titleStyle` and `descriptionStyle` are merged over the variant defaults.

```tsx
toast.info("Perfil actualizado", {
  description: "Tus cambios han sido guardados.",
  titleStyle: { fontSize: 16, fontWeight: "800" },
  descriptionStyle: { fontSize: 13, color: "#3F276F" },
  backgroundColor: "#E0D6F8",
});
```

# 🖼️ Icons

By default, each variant ships with a built-in icon. You can:

- Pass a custom `icon` as any React node (e.g. an SVG from `react-native-svg`, a `lucide-react-native` component, an `<Image />`, …).
- Pass `noIcon: true` to hide it entirely.

```tsx
import { MySvgIcon } from "./MySvgIcon";

// Custom icon
toast.success("Guardado", { icon: <MySvgIcon /> });

// No icon
toast.error("Algo salió mal. Intenta de nuevo.", { noIcon: true });
```

# 🎛️ `toast.custom`

Same as `toast(...)` but **`options` is required** — every field inside
remains optional. Use it when you want to signal at the call site that this
toast is explicitly customized (useful for linters / code reviews where a
forgotten options object should be a TS error, not a silent fallback).

```tsx
toast.custom("Brand message", {
  description: "Totalmente custom.",
  backgroundColor: "#0F172A",
  titleStyle: { color: "#F8FAFC" },
  descriptionStyle: { color: "#CBD5E1" },
  icon: <MyIcon />,
  duration: 4000,
});

// ❌ TS error — options is required
toast.custom("Nope");
```

# ⚙️ Full toast options

```tsx
toast("Example", {
  variant: "success",
  position: "top",
  duration: 4000,

  description: "Extra context line",

  icon: <MyIcon />,        // or noIcon: true
  noIcon: false,

  titleStyle: { fontSize: 16, fontWeight: "700", color: "#0F3D2E" },
  descriptionStyle: { fontSize: 13, color: "#1F5A43" },

  backgroundColor: "#D1F2CF",

  enterDuration: 300,
  exitDuration: 220,
});
```

# 🔧 Global configuration

```tsx
configureToasts({
  duration: 3000,
  position: "top",
  enterDuration: 300,
  exitDuration: 200,
  maxToasts: 3,

  titleStyle: { fontFamily: "Inter-Bold" },
  descriptionStyle: { fontFamily: "Inter" },
});
```

# ✋ Programmatic dismiss

`toast()` returns the id of the created toast. Use it to dismiss.

```tsx
const id = toast.info("Syncing…", { duration: 10000 });

// later
toast.dismiss(id);
```

# 🧪 Full example

See [`example/App.tsx`](./example/App.tsx) for a ready-to-drop-in screen that
demonstrates every variant, title + description, custom icons, `noIcon`,
style overrides, bottom position and programmatic dismiss.

# 🛣 Roadmap

Planned features:

- Swipe to dismiss
- Custom renderers (full `render(toast)` override)
- Light/dark theming & theme override API
- Toast groups / scopes
- Programmatic `update(id, options)` and `toast.promise(...)`
- Position-aware entry animation
- Accessibility announcements

PRs and discussions are welcome.
